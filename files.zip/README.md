# CA Freshwater Fishing Regulations Map — 2026

Interactive Leaflet.js map of California's special trout and salmon waters (§7.40 and §7.50).  
Stream geometry is fetched from the USGS National Hydrography Dataset (NHD).  
Multi-segment streams are **clipped to their actual geographic extent** and colored by individual regulation status.

---

## Architecture

```
2026_Freshwater_Sport_Fish_V3_011526.pdf   ← regulation text (included)
        │
        ▼
  parse_regulations.py      → data/regulations.json   (326 entries, ~84 multi-segment)
        │
        ▼
  fetch_nhd.py              → data/streams.geojson    (one GeoJSON Feature per segment)
        │
        ▼
  index.html                ← Leaflet map, served locally
```

### What makes this NHD-first

Previous approach fetched from Overpass API (OSM) and got wrong or missing geometry for ~30% of streams.

This version:
1. **Queries USGS NHD Plus HR** by `GNIS_Name` — the authoritative US hydrologic dataset, updated continuously
2. **Geocodes landmarks** (dams, bridges, road crossings) via Nominatim to find segment split points
3. **Clips the NHD LineString** at those points using Shapely's `substring()` operation
4. Each GeoJSON feature is **one regulation segment** with its own color/status

Example — American River (§7.40):

| Segment | Reach | Status |
|---------|-------|--------|
| (A) Nimbus Dam → USGS gauging station | ~300 yd | 🔴 Closed |
| (B) USGS station → Ancil Hoffman Park | ~4 mi | 🟠 Restricted |
| (C) Ancil Hoffman → Jibboom St. Bridge | ~8 mi | 🟢 Open |
| (D) Jibboom St. Bridge → mouth | ~2 mi | 🟢 Open |

---

## Setup

### 1. Install dependencies
```bash
pip install shapely
```

### 2. Parse regulations
```bash
python parse_regulations.py
```
Output: `data/regulations.json` — 326 regulation entries with segment descriptions and parsed bounds.

### 3. Fetch NHD geometry (needs internet)
```bash
python fetch_nhd.py
```
- Queries USGS NHD Plus HR REST API for each stream
- Geocodes `from/to` landmarks via Nominatim  
- Clips NHD linestrings into per-segment geometries using Shapely
- Saves progress to `data/nhd_checkpoint.json` (resumes on restart)
- Output: `data/streams.geojson`

To start fresh: `python fetch_nhd.py --reset`

### 4. Serve locally
```bash
python -m http.server 8080
# Open http://localhost:8080
```

---

## Data Files

### `data/regulations.json`
```json
{
  "streams": [
    {
      "id": "7.40_4",
      "section": "7.40",
      "name": "American River",
      "county": "Sacramento",
      "status": "mixed",
      "segments": [
        {
          "label": "A",
          "description": "From Nimbus Dam to the U.S. Geological Survey gauging station...",
          "open_season": "Closed to all fishing all year.",
          "bag_limit": "",
          "bounds": {
            "from_landmark": "Nimbus Dam",
            "to_landmark": "U.S. Geological Survey gauging station cable crossing..."
          }
        }
      ]
    }
  ]
}
```

### `data/streams.geojson`
Each GeoJSON Feature is **one regulation segment**:
```json
{
  "type": "Feature",
  "geometry": { "type": "LineString", "coordinates": [...] },
  "properties": {
    "id":        "7.40_4_s0",
    "stream_id": "7.40_4",      ← links back to regulations.json
    "seg_idx":   0,
    "seg_label": "A",
    "name":      "American River",
    "status":    "closed",      ← THIS segment's status
    "source":    "nhd",         ← or "nhd-approx" / "nominatim"
    "open_season": "Closed to all fishing all year.",
    "bag_limit":   "",
    "bounds": { "from_landmark": "Nimbus Dam", "to_landmark": "..." },
    "segments": [...]           ← full regulation text for detail panel
  }
}
```

### Clipping sources
| `source` value | Meaning |
|---|---|
| `nhd` | Clipped at geocoded landmark points |
| `nhd-approx` | Clipped proportionally (landmark geocoding failed) |
| `nominatim` | Point fallback (NHD returned no geometry) |

---

## Map Features

- **USGS Hydro overlay** — shows all CA waterways as blue reference layer
- **Status colors** — each segment line colored independently (open/restricted/closed/mixed/unknown)
- **Segment tabs** — multi-segment streams show tabs (A), (B), (C)… each with its own regulation detail
- **Boundary display** — "From X to Y" landmark text shown in detail panel
- **Search + filter** — filter by status or search by name/county
- **Checkpoint resume** — `fetch_nhd.py` saves progress every 10 streams

---

## Known Limitations

- Landmark geocoding via Nominatim is **approximate** — dams and bridge crossings often geocode correctly, but some obscure features (USGS cable crossings, SMUD power lines) may not be in Nominatim's database
- When landmark geocoding fails, segments are split **proportionally** along the NHD line and marked `source: "nhd-approx"`
- NHD may not have entries for every stream in the regulation; those fall back to a Nominatim point marker
- The text-file PDF parser handles the two-column layout heuristically — some `open_season` / `bag_limit` fields may have minor parsing artifacts

## Files

| File | Purpose |
|---|---|
| `parse_regulations.py` | Parse PDF text → `data/regulations.json` |
| `fetch_nhd.py` | Fetch NHD geometry + clip segments → `data/streams.geojson` |
| `index.html` | Leaflet map app (self-contained, no build step) |
| `data/regulations.json` | Parsed regulation entries (generated) |
| `data/streams.geojson` | Clipped NHD segment geometries (generated) |
| `data/nhd_checkpoint.json` | Fetch resume state (generated) |
